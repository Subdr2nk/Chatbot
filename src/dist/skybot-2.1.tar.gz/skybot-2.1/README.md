-- Welcome!
-- Im going to show you the setting up tree (__SPT__) & dirs!.

# SETUP DIR -- tree

C:
└───src
    ├───dist
    └───skybot
        └───models
             
        
# SETUP  D.I.R -- info

16/08/2023  08:10    <DIR>          .
16/08/2023  08:10    <DIR>          ..
16/08/2023  07:30                 0 .gitignore
16/08/2023  07:37               145 CHANGELOG.txt
16/08/2023  07:43    <DIR>          dist
16/08/2023  07:34             1.113 LICENSE.txt
16/08/2023  07:52                 0 MANIFEST.in
16/08/2023  07:30                 0 pyproject.toml
16/08/2023  08:10               187 README.md
16/08/2023  07:30                 0 setup.cfg
16/08/2023  08:08               340 setup.py
16/08/2023  07:43    <DIR>          skybot
16/08/2023  08:05                20 __init__.py

--This is the main files!

(NOTE: this project is in portuguese.)

